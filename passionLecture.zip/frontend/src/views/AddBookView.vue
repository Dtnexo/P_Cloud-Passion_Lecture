<script setup>
import AddBook from '@/components/addBook.vue'
</script>
<template>
  <h1>Ajouter un livre</h1>
  <AddBook />
</template>
<style scoped>
h1 {
  margin-top: 15px;
  font-size: 35px;
  font-weight: bold;
  text-align: center;
}
</style>
